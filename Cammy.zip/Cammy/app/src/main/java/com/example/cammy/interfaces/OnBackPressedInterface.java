package com.example.cammy.interfaces;

public interface OnBackPressedInterface {
    void closeBottomSheet();
    boolean checkSheetBehaviour();
}
