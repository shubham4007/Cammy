package com.example.cammy.interfaces;

public interface DataSetChanged {
    void updateDataset();
}
