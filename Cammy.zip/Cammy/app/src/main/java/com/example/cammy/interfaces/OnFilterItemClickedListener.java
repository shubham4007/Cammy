package com.example.cammy.interfaces;

import android.view.View;
public interface OnFilterItemClickedListener {
    void onItemClick(View v, int position);
}
