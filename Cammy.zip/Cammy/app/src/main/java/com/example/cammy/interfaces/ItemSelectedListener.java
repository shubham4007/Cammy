package com.example.cammy.interfaces;

public interface ItemSelectedListener {
    void isSelected(Boolean isSelected, int countFiles);
}