package com.example.cammy.interfaces;

public interface OnItemClickListener {

    void onItemClick(int position);
}
